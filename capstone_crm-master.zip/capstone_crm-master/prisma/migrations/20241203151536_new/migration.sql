-- AlterTable
ALTER TABLE `appointments` ADD COLUMN `description` VARCHAR(191) NULL;
